/*
 * Copyright (c)  2022 Ward van der Veer.  Licensed under the Apache Licence.
 */

package example.sbapp.webdav;

import example.sbapp.config.SysCfg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import wv.webdav.WebDavDrive;
import wv.webdav.WebDavException;
import wv.webdav.WebDavFile;
import wv.webdav.WebDavFolder;

import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;

@Controller
public class WebDavController {

    @Autowired
    private SysCfg sysCfg;

    private WebDavDrive webDavDrive;

    @NonNull
    private WebDavDrive getWebDavDrive() {
       if (webDavDrive == null) {
           // create the WebDAV drive
           webDavDrive = new WebDavDrive(sysCfg.getCtxPath() + "/WebDAV");
           // create initial content for the WebDAV drive
           WebDavFolder exampleFolder = new WebDavFolder(webDavDrive, "example");
           WebDavFile exampleFile = new WebDavFile(exampleFolder, "test.txt") {
               @Override
               public String getContentType() {
                   return MediaType.TEXT_PLAIN.toString();
               }

               @Override
               public byte[] getContent() throws WebDavException {
                   return "This is a test\n".getBytes(StandardCharsets.UTF_8);
               }
           };
       }
       return webDavDrive;
    }


    @RequestMapping(value="/WebDAV/**")
    @NonNull
    public ResponseEntity<byte[]> handleWebDavRequest(@NonNull HttpServletRequest req) {
        if (req.getHeader(HttpHeaders.AUTHORIZATION) == null ||
            req.getHeader(HttpHeaders.AUTHORIZATION).startsWith("Negotiate")) {
            return ResponseEntity
                    .status(401)
                    .header(HttpHeaders.WWW_AUTHENTICATE, "Basic")
                    .body("Login required".getBytes(StandardCharsets.UTF_8));
        }
        ResponseEntity<byte[]> rsp = getWebDavDrive().handleRequest(req);
        return rsp;
    }

}
