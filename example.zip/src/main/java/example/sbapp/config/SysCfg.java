/*
 * Copyright (c)  2022 Ward van der Veer.  Licensed under the Apache Licence.
 */

package example.sbapp.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SysCfg {

    @Value("${server.servlet.context-path}")
    private String ctxPath;

    public String getCtxPath() {
        return ctxPath;
    }

}
